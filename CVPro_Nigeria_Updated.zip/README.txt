CVPro Nigeria updated website

Your WhatsApp number has been added to all order buttons:
+234 703 139 0856

Upload index.html to the root of your GitHub Pages repository.
